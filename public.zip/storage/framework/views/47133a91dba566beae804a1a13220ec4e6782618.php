<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">List of Students and Registered Courses</div>

                <div class="card-body">
                    <?php if(!is_null($registeredStudents)): ?>
                    <?php $i =0; ?>
                        <?php $__currentLoopData = $registeredStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <div class="table-responsive" style="margin-bottom: 3em">
                                <div style="background-color: #fafafc; color: #333"><b><?php echo e($i); ?> : <?php echo e($student->name); ?></b></div>
                                <?php if(!is_null($student->studentCourses)): ?>  
                                    <table class="table-striped" cellpadding="10"> 
                                    <thead>
                                        <th>Course Title</th>
                                        <th>Course Description</th>
                                        <th>Credit Unit</th>
                                    </thead>                         
                                    <?php $__currentLoopData = $student->studentCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $thisCourse = App\Course::where('id', $course->course_id)->first();
                                        ?>
                                        <tr>
                                            <td> <?php echo e($thisCourse->course_title); ?></td>
                                            <td> <?php echo e($thisCourse->description); ?></td>
                                            <td> <?php echo e($thisCourse->credit_unit); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                                <?php endif; ?>
                                
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprojects\ia2ztech_test\resources\views/registered_students.blade.php ENDPATH**/ ?>