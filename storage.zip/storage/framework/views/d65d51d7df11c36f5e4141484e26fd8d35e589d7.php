<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!

                    <?php if(Auth::user()->user_type == 'admin'): ?>
                        <h1>Welcome Admin</h1>
                        <div class="links">
                            <a href="<?php echo e(url('/course/add')); ?>">Create a Course</a><br/>
                            <a href="<?php echo e(url('/course/view')); ?>">View Courses</a><br/>
                            <a href="<?php echo e(url('/registration/view')); ?>">View Students' Course Registration</a>
                        </div>
                    <?php else: ?>
                        <h1>Welcome Student</h1>
                        <div class="links">
                            <a href="<?php echo e(url('/course/register')); ?>">Register/Unregister Courses</a><br/>
                            <a href="<?php echo e(url('/course/view/student',['id'=>Auth::user()->id])); ?>">View My Courses</a><br/>
                            <a href="<?php echo e(url('/profile/view')); ?>">View Profile</a>
                        </div>

                    <?php endif; ?>

                    <?php if(isset($message)): ?>
                        <p style="color:#f00; margin-top: 2em"><?php echo e($message); ?></p> 
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprojects\ia2ztech_test\resources\views/home.blade.php ENDPATH**/ ?>