<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">List of Registered Courses</div>

                <div class="card-body">
                    <?php if(!is_null($registeredCourses)): ?>
                        <div class="table-responsive">
                            <table class="table-striped" cellpadding="10"> 
                                <thead>
                                    <th>Course Title</th>
                                    <th>Course Description</th>
                                    <th>Credit Unit</th>
                                </thead>                           
                                <?php $__currentLoopData = $registeredCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $thisCourse = App\Course::where('id', $course->course_id)->first();
                                    ?>
                                    <tr>
                                        <td> <?php echo e($thisCourse->course_title); ?></td>
                                        <td> <?php echo e($thisCourse->description); ?></td>
                                        <td> <?php echo e($thisCourse->credit_unit); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    <?php else: ?>
                        Empty list
                   <?php endif; ?>

                    <?php if(count($registeredCourses) ==0): ?>
                        Empty list
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprojects\ia2ztech_test\resources\views/student_courses.blade.php ENDPATH**/ ?>