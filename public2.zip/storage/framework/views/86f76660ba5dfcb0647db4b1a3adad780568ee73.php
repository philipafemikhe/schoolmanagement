<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Course')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/course/add')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="courseTitle" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Course Title')); ?></label>

                            <div class="col-md-6">
                                <input id="courseTitle" type="text" class="form-control <?php if ($errors->has('courseTitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('courseTitle'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="courseTitle" value="<?php echo e(old('courseTitle')); ?>" required autocomplete="courseTitle" autofocus>

                                <?php if ($errors->has('courseTitle')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('courseTitle'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <textarea id="description"  name="description" rows="4" class="form-control"></textarea> 

                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="creditUnit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Credit Unit')); ?></label>

                            <div class="col-md-6">
                                <input id="creditUnit" type="text" class="form-control <?php if ($errors->has('creditUnit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('creditUnit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="creditUnit" required>

                                <?php if ($errors->has('creditUnit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('creditUnit'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                      
                         <div class="form-group row">
                            <label for="className" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Class')); ?></label>

                            <div class="col-md-6">
                                <select id="className" class="form-control" name="className" required>
                                    <option value="null">Select one</option>
                                    <option value="100 Level">100 Level</option>
                                    <option value="200 Level">200 Level</option>
                                    <option value="300 Level">300 Level</option>
                                    <option value="400 Level">400 Level</option>
                                </select>
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Save Course')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprojects\ia2ztech_test\resources\views/addCourseForm.blade.php ENDPATH**/ ?>