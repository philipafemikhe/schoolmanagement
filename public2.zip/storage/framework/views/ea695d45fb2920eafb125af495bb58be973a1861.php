<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Available Courses</div>

                <div class="card-body">
                    <?php if(!empty($courses)): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <th>Course Title</th>
                                    <th>Course Description</th>
                                    <th>Credit Unit</th>
                                    <th>Class offered</th>
                                </thead>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($course->course_title); ?></td>
                                        <td><?php echo e($course->description); ?></td>
                                        <td><?php echo e($course->credit_unit); ?></td>
                                        <td><?php echo e($course->class); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelprojects\ia2ztech_test\resources\views/course_list.blade.php ENDPATH**/ ?>